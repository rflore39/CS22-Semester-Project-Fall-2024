﻿namespace Semester_Project
{
    partial class FormulaCalculations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labeltitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDisplacement = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnExitFC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labeltitle
            // 
            this.labeltitle.AutoSize = true;
            this.labeltitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labeltitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labeltitle.Location = new System.Drawing.Point(134, 41);
            this.labeltitle.Name = "labeltitle";
            this.labeltitle.Size = new System.Drawing.Size(1297, 110);
            this.labeltitle.TabIndex = 0;
            this.labeltitle.Text = "FORMULA CALCULATIONS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(473, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(646, 55);
            this.label1.TabIndex = 1;
            this.label1.Text = "Press any button to continue.";
            // 
            // btnDisplacement
            // 
            this.btnDisplacement.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplacement.Location = new System.Drawing.Point(134, 446);
            this.btnDisplacement.Name = "btnDisplacement";
            this.btnDisplacement.Size = new System.Drawing.Size(333, 185);
            this.btnDisplacement.TabIndex = 2;
            this.btnDisplacement.Text = "Displacement";
            this.btnDisplacement.UseVisualStyleBackColor = true;
            this.btnDisplacement.Click += new System.EventHandler(this.btnDisplacement_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(619, 446);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(333, 185);
            this.button1.TabIndex = 3;
            this.button1.Text = "Voltage";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnExitFC
            // 
            this.btnExitFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitFC.Location = new System.Drawing.Point(1098, 446);
            this.btnExitFC.Name = "btnExitFC";
            this.btnExitFC.Size = new System.Drawing.Size(333, 185);
            this.btnExitFC.TabIndex = 4;
            this.btnExitFC.Text = "Exit Application";
            this.btnExitFC.UseVisualStyleBackColor = true;
            this.btnExitFC.Click += new System.EventHandler(this.btnExitFC_Click);
            // 
            // FormulaCalculations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1578, 844);
            this.Controls.Add(this.btnExitFC);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnDisplacement);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labeltitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FormulaCalculations";
            this.Text = "Formula Calculations";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labeltitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDisplacement;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExitFC;
    }
}