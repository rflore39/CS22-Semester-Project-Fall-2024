﻿/*
 * Author Name : Roman Flores
 * 
 * Date : 12/4/2024
 * 
 * Email: rflore39@students.solano.edu
 * 
 * Class : CS22 MW 11:00 AM - 12:50 PM
 * 
 * Description: This is a simple Physics application that can perform some unit conversions,
 * prefix conversions, and can solve a couple elementary Physics problems accurately.
 * 
 * Solano Pledge : As a Falcon @ Solano College, I will not lie, cheat, or steal, nor will I
 * accept the actions of those who do. This program is solely my work, or proper attribution
 * has been given to code I did not write. If I am found to violate this policy, I realize I
 * will receive an F for this course with no exception.
 * 
 * Sources used to complete project: https://www.youtube.com/watch?v=Bvx8cZxIFZE
 * The application above helped in creating a simple user-friendly menu for the user
 * to navigate through. 
 * Used in Form 1 (lines 43-44, 49-50, 55-566) and Form 4 (lines 27-28, 33-34).
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class PhysicsApplication : Form
    {
        public PhysicsApplication()
        {
            InitializeComponent();
        }

        // Create menu to navigate through functions
        private void UnitConversions_Click(object sender, EventArgs e)
        {
            UnitConversions uc = new UnitConversions();
            uc.ShowDialog();
        }

        private void PrefixConversions_Click(object sender, EventArgs e)
        {
            PrefixConversions pc = new PrefixConversions();
            pc.ShowDialog();
        }

        private void FormulaCalculations_Click(object sender, EventArgs e)
        {
            FormulaCalculations fc = new FormulaCalculations();
            fc.ShowDialog();
        }
        // Exit
        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
