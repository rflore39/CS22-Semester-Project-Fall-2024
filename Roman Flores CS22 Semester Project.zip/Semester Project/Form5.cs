﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class Displacement : Form
    {
        public Displacement()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        // Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // Clear all
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtIP.Text = string.Empty;
            txtIV.Text = string.Empty;
            txtA.Text = string.Empty;
            txtT.Text = string.Empty;
            txtFP.Text = string.Empty;
            txtIP.Focus();
        }
        // calculate displacement / final position
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double xo = 0.00000;
            double vo = 0.0000;
            double a = 0.0000;
            double t = 0.0000;
            xo = Convert.ToDouble(txtIP.Text);
            vo = Convert.ToDouble(txtIV.Text);
            a = Convert.ToDouble(txtA.Text);
            t = Convert.ToDouble(txtT.Text);
            double FP = xo + vo * t + 0.5 * a * t * t;
            txtFP.Text = FP.ToString();
        }
    }
}
