﻿namespace Semester_Project
{
    partial class PhysicsApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UnitConversions = new System.Windows.Forms.Button();
            this.PrefixConversions = new System.Windows.Forms.Button();
            this.FormulaCalculations = new System.Windows.Forms.Button();
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelMenu = new System.Windows.Forms.Label();
            this.labelDirection = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UnitConversions
            // 
            this.UnitConversions.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnitConversions.Location = new System.Drawing.Point(24, 414);
            this.UnitConversions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.UnitConversions.Name = "UnitConversions";
            this.UnitConversions.Size = new System.Drawing.Size(225, 114);
            this.UnitConversions.TabIndex = 0;
            this.UnitConversions.Text = "Unit Conversions";
            this.UnitConversions.UseVisualStyleBackColor = true;
            this.UnitConversions.Click += new System.EventHandler(this.UnitConversions_Click);
            // 
            // PrefixConversions
            // 
            this.PrefixConversions.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrefixConversions.Location = new System.Drawing.Point(285, 414);
            this.PrefixConversions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PrefixConversions.Name = "PrefixConversions";
            this.PrefixConversions.Size = new System.Drawing.Size(225, 114);
            this.PrefixConversions.TabIndex = 1;
            this.PrefixConversions.Text = "Prefix Conversions";
            this.PrefixConversions.UseVisualStyleBackColor = true;
            this.PrefixConversions.Click += new System.EventHandler(this.PrefixConversions_Click);
            // 
            // FormulaCalculations
            // 
            this.FormulaCalculations.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormulaCalculations.Location = new System.Drawing.Point(545, 414);
            this.FormulaCalculations.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FormulaCalculations.Name = "FormulaCalculations";
            this.FormulaCalculations.Size = new System.Drawing.Size(225, 114);
            this.FormulaCalculations.TabIndex = 2;
            this.FormulaCalculations.Text = "Formula Calculations";
            this.FormulaCalculations.UseVisualStyleBackColor = true;
            this.FormulaCalculations.Click += new System.EventHandler(this.FormulaCalculations_Click);
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelTitle.Location = new System.Drawing.Point(144, 42);
            this.labelTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(1148, 110);
            this.labelTitle.TabIndex = 3;
            this.labelTitle.Text = "PHYSICS APPLICATION";
            // 
            // labelMenu
            // 
            this.labelMenu.AutoSize = true;
            this.labelMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMenu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelMenu.Location = new System.Drawing.Point(397, 164);
            this.labelMenu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMenu.Name = "labelMenu";
            this.labelMenu.Size = new System.Drawing.Size(400, 82);
            this.labelMenu.TabIndex = 4;
            this.labelMenu.Text = "Main Menu";
            // 
            // labelDirection
            // 
            this.labelDirection.AutoSize = true;
            this.labelDirection.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDirection.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelDirection.Location = new System.Drawing.Point(262, 276);
            this.labelDirection.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDirection.Name = "labelDirection";
            this.labelDirection.Size = new System.Drawing.Size(803, 55);
            this.labelDirection.TabIndex = 5;
            this.labelDirection.Text = "Please select an option to continue";
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(806, 414);
            this.Exit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(225, 114);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // PhysicsApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(1578, 844);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.labelDirection);
            this.Controls.Add(this.labelMenu);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.FormulaCalculations);
            this.Controls.Add(this.PrefixConversions);
            this.Controls.Add(this.UnitConversions);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PhysicsApplication";
            this.Text = "Physics Application";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button UnitConversions;
        private System.Windows.Forms.Button PrefixConversions;
        private System.Windows.Forms.Button FormulaCalculations;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelMenu;
        private System.Windows.Forms.Label labelDirection;
        private System.Windows.Forms.Button Exit;
    }
}

