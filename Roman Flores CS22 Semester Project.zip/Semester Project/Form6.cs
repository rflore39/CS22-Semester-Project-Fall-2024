﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class Voltage : Form
    {
        public Voltage()
        {
            InitializeComponent();
        }
        //Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Calculate voltage
        private void btnVolt_Click(object sender, EventArgs e)
        {
            double Cur = 0.0000;
            double Res = 0.0000;
            Cur = Convert.ToDouble(txtCur.Text);
            Res = Convert.ToDouble(txtRes.Text);
            double Volt = Cur * Res;
            txtOutput.Text = Volt.ToString();
        }
        //Calculate current
        private void btnCurrent_Click(object sender, EventArgs e)
        {
            double Volt1 = 0.0000;
            double Res1 = 0.0000;
            Volt1 = Convert.ToDouble(txtVolt.Text);
            Res1 = Convert.ToDouble(txtRes.Text);
            double Cur1 = Volt1 / Res1;
            txtOutput.Text = Cur1.ToString();
        }
        //Calculate resistance
        private void btnResistance_Click(object sender, EventArgs e)
        {
            double Volt2 = 0.0000;
            double Cur2 = 0.0000;
            Volt2 = Convert.ToDouble(txtVolt.Text);
            Cur2 = Convert.ToDouble(txtCur.Text);
            double Res2 = Volt2 / Cur2;
            txtOutput.Text = Res2.ToString();

        }
        //Clear all
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtVolt.Text = string.Empty;
            txtRes.Text = string.Empty;
            txtCur.Text = string.Empty;
            txtOutput.Text = string.Empty;
            txtVolt.Focus();
        }
    }
}
