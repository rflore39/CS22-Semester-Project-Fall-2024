﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class FormulaCalculations : Form
    {
        public FormulaCalculations()
        {
            InitializeComponent();
        }
        //exit
        private void btnExitFC_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //create menu
        private void btnDisplacement_Click(object sender, EventArgs e)
        {
            Displacement dis = new Displacement();
            dis.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Voltage volt = new Voltage();   
            volt.ShowDialog();
        }
    }
}
