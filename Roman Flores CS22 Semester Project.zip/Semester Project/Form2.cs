﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class UnitConversions : Form
    {
        public UnitConversions()
        {
            InitializeComponent();
        }
        // exit
        private void btnUCExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // clear all
        private void btnUCClear_Click(object sender, EventArgs e)
        {
            txtUCInput.Text = string.Empty;

            txtUCOutput.Text = string.Empty;
            txtUCInput.Focus();
        }
        // convert kilometers to miles
        private void btnKmToMi_Click(object sender, EventArgs e)
        {
            double KmInput = 0.0000;
            KmInput = Convert.ToDouble(txtUCInput.Text);
            double MiOutput = KmInput * 0.6214;
            txtUCOutput.Text = MiOutput.ToString();
        }
        // convert miles to kilometers
        private void btnMiToKm_Click(object sender, EventArgs e)
        {
            double MiInput = 0.0000;
            MiInput = Convert.ToDouble(txtUCInput.Text);
            double KmOutput = MiInput / 0.6214;
            txtUCOutput.Text = KmOutput.ToString();
        }
        // convert meters to feet
        private void btnMToFt_Click(object sender, EventArgs e)
        {
            double MInput = 0.0000;
            MInput = Convert.ToDouble(txtUCInput.Text);
            double FtOutput = MInput * 10.76;
            txtUCOutput.Text = FtOutput.ToString();
        }
        // convert feet to meters
        private void btnFtToM_Click(object sender, EventArgs e)
        {
            double FtInput = 0.0000;
            FtInput = Convert.ToDouble(txtUCInput.Text);
            double MOutput = FtInput / 10.76;
            txtUCOutput.Text= MOutput.ToString();
        }
        // convert kilograms to pounds
        private void btnKgToLb_Click(object sender, EventArgs e)
        {
            double KgInput = 0.0000;
            KgInput = Convert.ToDouble(txtUCInput.Text);
            double LbOutput = KgInput * 2.205;
            txtUCOutput.Text = LbOutput.ToString();
        }
        // convert pounds to kilograms
        private void btnLbToKg_Click(object sender, EventArgs e)
        {
            double LbInput = 0.0000;
            LbInput = Convert.ToDouble(txtUCInput.Text);
            double KgOutput = LbInput / 2.205;
            txtUCOutput.Text = KgOutput.ToString();
        }
    }
}
