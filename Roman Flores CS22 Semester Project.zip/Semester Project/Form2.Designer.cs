﻿namespace Semester_Project
{
    partial class UnitConversions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUnitTitle = new System.Windows.Forms.Label();
            this.labelUCDirections = new System.Windows.Forms.Label();
            this.labelMtI = new System.Windows.Forms.Label();
            this.labelItoM = new System.Windows.Forms.Label();
            this.btnKmToMi = new System.Windows.Forms.Button();
            this.btnMToFt = new System.Windows.Forms.Button();
            this.btnKgToLb = new System.Windows.Forms.Button();
            this.btnMiToKm = new System.Windows.Forms.Button();
            this.btnLbToKg = new System.Windows.Forms.Button();
            this.btnFtToM = new System.Windows.Forms.Button();
            this.labelAreaI = new System.Windows.Forms.Label();
            this.labelWeightI = new System.Windows.Forms.Label();
            this.labelLengthI = new System.Windows.Forms.Label();
            this.labelWeightM = new System.Windows.Forms.Label();
            this.labelAreaM = new System.Windows.Forms.Label();
            this.labelLengthM = new System.Windows.Forms.Label();
            this.labelInput = new System.Windows.Forms.Label();
            this.labelOutput = new System.Windows.Forms.Label();
            this.txtUCInput = new System.Windows.Forms.TextBox();
            this.txtUCOutput = new System.Windows.Forms.TextBox();
            this.btnUCClear = new System.Windows.Forms.Button();
            this.btnUCExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelUnitTitle
            // 
            this.labelUnitTitle.AutoSize = true;
            this.labelUnitTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelUnitTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelUnitTitle.Location = new System.Drawing.Point(34, 25);
            this.labelUnitTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelUnitTitle.Name = "labelUnitTitle";
            this.labelUnitTitle.Size = new System.Drawing.Size(1474, 84);
            this.labelUnitTitle.TabIndex = 0;
            this.labelUnitTitle.Text = "UNIT CONVERSIONS (Metric and Imperial)";
            // 
            // labelUCDirections
            // 
            this.labelUCDirections.AutoSize = true;
            this.labelUCDirections.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCDirections.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelUCDirections.Location = new System.Drawing.Point(267, 98);
            this.labelUCDirections.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelUCDirections.Name = "labelUCDirections";
            this.labelUCDirections.Size = new System.Drawing.Size(778, 55);
            this.labelUCDirections.TabIndex = 1;
            this.labelUCDirections.Text = "Please select a function to execute.";
            // 
            // labelMtI
            // 
            this.labelMtI.AutoSize = true;
            this.labelMtI.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMtI.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelMtI.Location = new System.Drawing.Point(27, 162);
            this.labelMtI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMtI.Name = "labelMtI";
            this.labelMtI.Size = new System.Drawing.Size(390, 55);
            this.labelMtI.TabIndex = 2;
            this.labelMtI.Text = "Metric to Imperial";
            // 
            // labelItoM
            // 
            this.labelItoM.AutoSize = true;
            this.labelItoM.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItoM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelItoM.Location = new System.Drawing.Point(757, 162);
            this.labelItoM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelItoM.Name = "labelItoM";
            this.labelItoM.Size = new System.Drawing.Size(390, 55);
            this.labelItoM.TabIndex = 3;
            this.labelItoM.Text = "Imperial to Metric";
            // 
            // btnKmToMi
            // 
            this.btnKmToMi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKmToMi.Location = new System.Drawing.Point(145, 205);
            this.btnKmToMi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnKmToMi.Name = "btnKmToMi";
            this.btnKmToMi.Size = new System.Drawing.Size(143, 70);
            this.btnKmToMi.TabIndex = 4;
            this.btnKmToMi.Text = "Kilometers to Miles";
            this.btnKmToMi.UseVisualStyleBackColor = true;
            this.btnKmToMi.Click += new System.EventHandler(this.btnKmToMi_Click);
            // 
            // btnMToFt
            // 
            this.btnMToFt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMToFt.Location = new System.Drawing.Point(145, 289);
            this.btnMToFt.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMToFt.Name = "btnMToFt";
            this.btnMToFt.Size = new System.Drawing.Size(143, 70);
            this.btnMToFt.TabIndex = 6;
            this.btnMToFt.Text = "Meters^2 to Feet^2";
            this.btnMToFt.UseVisualStyleBackColor = true;
            this.btnMToFt.Click += new System.EventHandler(this.btnMToFt_Click);
            // 
            // btnKgToLb
            // 
            this.btnKgToLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKgToLb.Location = new System.Drawing.Point(145, 374);
            this.btnKgToLb.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnKgToLb.Name = "btnKgToLb";
            this.btnKgToLb.Size = new System.Drawing.Size(143, 70);
            this.btnKgToLb.TabIndex = 7;
            this.btnKgToLb.Text = "Kilograms to Pounds";
            this.btnKgToLb.UseVisualStyleBackColor = true;
            this.btnKgToLb.Click += new System.EventHandler(this.btnKgToLb_Click);
            // 
            // btnMiToKm
            // 
            this.btnMiToKm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMiToKm.Location = new System.Drawing.Point(874, 205);
            this.btnMiToKm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMiToKm.Name = "btnMiToKm";
            this.btnMiToKm.Size = new System.Drawing.Size(143, 70);
            this.btnMiToKm.TabIndex = 9;
            this.btnMiToKm.Text = "Miles to Kilometers";
            this.btnMiToKm.UseVisualStyleBackColor = true;
            this.btnMiToKm.Click += new System.EventHandler(this.btnMiToKm_Click);
            // 
            // btnLbToKg
            // 
            this.btnLbToKg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLbToKg.Location = new System.Drawing.Point(874, 374);
            this.btnLbToKg.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLbToKg.Name = "btnLbToKg";
            this.btnLbToKg.Size = new System.Drawing.Size(143, 70);
            this.btnLbToKg.TabIndex = 11;
            this.btnLbToKg.Text = "Pounds to Kilograms";
            this.btnLbToKg.UseVisualStyleBackColor = true;
            this.btnLbToKg.Click += new System.EventHandler(this.btnLbToKg_Click);
            // 
            // btnFtToM
            // 
            this.btnFtToM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFtToM.Location = new System.Drawing.Point(874, 289);
            this.btnFtToM.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnFtToM.Name = "btnFtToM";
            this.btnFtToM.Size = new System.Drawing.Size(143, 70);
            this.btnFtToM.TabIndex = 12;
            this.btnFtToM.Text = "Feet^2 to Meters^2";
            this.btnFtToM.UseVisualStyleBackColor = true;
            this.btnFtToM.Click += new System.EventHandler(this.btnFtToM_Click);
            // 
            // labelAreaI
            // 
            this.labelAreaI.AutoSize = true;
            this.labelAreaI.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAreaI.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelAreaI.Location = new System.Drawing.Point(759, 311);
            this.labelAreaI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAreaI.Name = "labelAreaI";
            this.labelAreaI.Size = new System.Drawing.Size(94, 37);
            this.labelAreaI.TabIndex = 13;
            this.labelAreaI.Text = "Area:";
            // 
            // labelWeightI
            // 
            this.labelWeightI.AutoSize = true;
            this.labelWeightI.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWeightI.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelWeightI.Location = new System.Drawing.Point(759, 396);
            this.labelWeightI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWeightI.Name = "labelWeightI";
            this.labelWeightI.Size = new System.Drawing.Size(126, 37);
            this.labelWeightI.TabIndex = 14;
            this.labelWeightI.Text = "Weight:";
            // 
            // labelLengthI
            // 
            this.labelLengthI.AutoSize = true;
            this.labelLengthI.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLengthI.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelLengthI.Location = new System.Drawing.Point(760, 227);
            this.labelLengthI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLengthI.Name = "labelLengthI";
            this.labelLengthI.Size = new System.Drawing.Size(124, 37);
            this.labelLengthI.TabIndex = 15;
            this.labelLengthI.Text = "Length:";
            // 
            // labelWeightM
            // 
            this.labelWeightM.AutoSize = true;
            this.labelWeightM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWeightM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelWeightM.Location = new System.Drawing.Point(29, 396);
            this.labelWeightM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWeightM.Name = "labelWeightM";
            this.labelWeightM.Size = new System.Drawing.Size(126, 37);
            this.labelWeightM.TabIndex = 16;
            this.labelWeightM.Text = "Weight:";
            // 
            // labelAreaM
            // 
            this.labelAreaM.AutoSize = true;
            this.labelAreaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAreaM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelAreaM.Location = new System.Drawing.Point(29, 311);
            this.labelAreaM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAreaM.Name = "labelAreaM";
            this.labelAreaM.Size = new System.Drawing.Size(94, 37);
            this.labelAreaM.TabIndex = 17;
            this.labelAreaM.Text = "Area:";
            // 
            // labelLengthM
            // 
            this.labelLengthM.AutoSize = true;
            this.labelLengthM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLengthM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelLengthM.Location = new System.Drawing.Point(29, 227);
            this.labelLengthM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLengthM.Name = "labelLengthM";
            this.labelLengthM.Size = new System.Drawing.Size(124, 37);
            this.labelLengthM.TabIndex = 18;
            this.labelLengthM.Text = "Length:";
            // 
            // labelInput
            // 
            this.labelInput.AutoSize = true;
            this.labelInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInput.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelInput.Location = new System.Drawing.Point(356, 205);
            this.labelInput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInput.Name = "labelInput";
            this.labelInput.Size = new System.Drawing.Size(531, 55);
            this.labelInput.TabIndex = 19;
            this.labelInput.Text = "Please enter your input:";
            // 
            // labelOutput
            // 
            this.labelOutput.AutoSize = true;
            this.labelOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOutput.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelOutput.Location = new System.Drawing.Point(423, 374);
            this.labelOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelOutput.Name = "labelOutput";
            this.labelOutput.Size = new System.Drawing.Size(333, 55);
            this.labelOutput.TabIndex = 21;
            this.labelOutput.Text = "Your output is:";
            // 
            // txtUCInput
            // 
            this.txtUCInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUCInput.Location = new System.Drawing.Point(363, 243);
            this.txtUCInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtUCInput.Name = "txtUCInput";
            this.txtUCInput.Size = new System.Drawing.Size(351, 62);
            this.txtUCInput.TabIndex = 22;
            // 
            // txtUCOutput
            // 
            this.txtUCOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUCOutput.Location = new System.Drawing.Point(363, 411);
            this.txtUCOutput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtUCOutput.Name = "txtUCOutput";
            this.txtUCOutput.Size = new System.Drawing.Size(351, 62);
            this.txtUCOutput.TabIndex = 24;
            // 
            // btnUCClear
            // 
            this.btnUCClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUCClear.Location = new System.Drawing.Point(363, 471);
            this.btnUCClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUCClear.Name = "btnUCClear";
            this.btnUCClear.Size = new System.Drawing.Size(143, 70);
            this.btnUCClear.TabIndex = 25;
            this.btnUCClear.Text = "Clear All";
            this.btnUCClear.UseVisualStyleBackColor = true;
            this.btnUCClear.Click += new System.EventHandler(this.btnUCClear_Click);
            // 
            // btnUCExit
            // 
            this.btnUCExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUCExit.Location = new System.Drawing.Point(569, 471);
            this.btnUCExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUCExit.Name = "btnUCExit";
            this.btnUCExit.Size = new System.Drawing.Size(143, 70);
            this.btnUCExit.TabIndex = 26;
            this.btnUCExit.Text = "Exit Application";
            this.btnUCExit.UseVisualStyleBackColor = true;
            this.btnUCExit.Click += new System.EventHandler(this.btnUCExit_Click);
            // 
            // UnitConversions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.ClientSize = new System.Drawing.Size(1607, 847);
            this.Controls.Add(this.btnUCExit);
            this.Controls.Add(this.btnUCClear);
            this.Controls.Add(this.txtUCOutput);
            this.Controls.Add(this.txtUCInput);
            this.Controls.Add(this.labelOutput);
            this.Controls.Add(this.labelInput);
            this.Controls.Add(this.labelLengthM);
            this.Controls.Add(this.labelAreaM);
            this.Controls.Add(this.labelWeightM);
            this.Controls.Add(this.labelLengthI);
            this.Controls.Add(this.labelWeightI);
            this.Controls.Add(this.labelAreaI);
            this.Controls.Add(this.btnFtToM);
            this.Controls.Add(this.btnLbToKg);
            this.Controls.Add(this.btnMiToKm);
            this.Controls.Add(this.btnKgToLb);
            this.Controls.Add(this.btnMToFt);
            this.Controls.Add(this.btnKmToMi);
            this.Controls.Add(this.labelItoM);
            this.Controls.Add(this.labelMtI);
            this.Controls.Add(this.labelUCDirections);
            this.Controls.Add(this.labelUnitTitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UnitConversions";
            this.Text = "Unit Conversions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUnitTitle;
        private System.Windows.Forms.Label labelUCDirections;
        private System.Windows.Forms.Label labelMtI;
        private System.Windows.Forms.Label labelItoM;
        private System.Windows.Forms.Button btnKmToMi;
        private System.Windows.Forms.Button btnMToFt;
        private System.Windows.Forms.Button btnKgToLb;
        private System.Windows.Forms.Button btnMiToKm;
        private System.Windows.Forms.Button btnLbToKg;
        private System.Windows.Forms.Button btnFtToM;
        private System.Windows.Forms.Label labelAreaI;
        private System.Windows.Forms.Label labelWeightI;
        private System.Windows.Forms.Label labelLengthI;
        private System.Windows.Forms.Label labelWeightM;
        private System.Windows.Forms.Label labelAreaM;
        private System.Windows.Forms.Label labelLengthM;
        private System.Windows.Forms.Label labelInput;
        private System.Windows.Forms.Label labelOutput;
        private System.Windows.Forms.TextBox txtUCInput;
        private System.Windows.Forms.TextBox txtUCOutput;
        private System.Windows.Forms.Button btnUCClear;
        private System.Windows.Forms.Button btnUCExit;
    }
}