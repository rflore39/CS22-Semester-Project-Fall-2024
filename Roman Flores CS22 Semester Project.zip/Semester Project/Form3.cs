﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semester_Project
{
    public partial class PrefixConversions : Form
    {
        public PrefixConversions()
        {
            InitializeComponent();
        }
        
        private void txtPrefixOutput_TextChanged(object sender, EventArgs e)
        {

        }
        // exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // clear all
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPrefixInput.Text = string.Empty;
            txtPrefixOutput.Text = string.Empty;
            txtPrefixInput.Focus();
        }
        // convert kilo- to uni-
        private void button1_Click(object sender, EventArgs e)
        {
            double KiloInput = 0.0000;
            KiloInput = Convert.ToDouble(txtPrefixInput.Text);
            double UniOutputK = KiloInput * 1000;
            txtPrefixOutput.Text = UniOutputK.ToString();


            
        }
        // convert uni- to kilo-
        private void btnUniToKilo_Click(object sender, EventArgs e)
        {
            double UniInputK = 0.0000;
            UniInputK = Convert.ToDouble(txtPrefixInput.Text);
            double KiloOutput = UniInputK / 1000;
            txtPrefixOutput.Text = KiloOutput.ToString();
        }
        // convert mili- to uni-
        private void btnMiliToUni_Click(object sender, EventArgs e)
        {
            double MiliInput = 0.0000;
            MiliInput = Convert.ToDouble(txtPrefixInput.Text);
            double UniOutputM = MiliInput / 1000;
            txtPrefixOutput.Text = UniOutputM.ToString();
        }
        // convert uni- to mili-
        private void btnUniToMili_Click(object sender, EventArgs e)
        {
            double UniInputM = 0.0000;
            UniInputM = Convert.ToDouble(txtPrefixInput.Text);
            double MiliOutput = UniInputM * 1000;
            txtPrefixOutput.Text = MiliOutput.ToString();
        }
    }
}
