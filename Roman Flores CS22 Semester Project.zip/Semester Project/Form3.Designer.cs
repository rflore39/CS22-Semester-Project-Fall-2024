﻿namespace Semester_Project
{
    partial class PrefixConversions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPrefixTitle = new System.Windows.Forms.Label();
            this.labelPrefixInput = new System.Windows.Forms.Label();
            this.labelSelect = new System.Windows.Forms.Label();
            this.labelPrefixOutput = new System.Windows.Forms.Label();
            this.txtPrefixInput = new System.Windows.Forms.TextBox();
            this.txtPrefixOutput = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnUniToKilo = new System.Windows.Forms.Button();
            this.btnMiliToUni = new System.Windows.Forms.Button();
            this.btnUniToMili = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelPrefixTitle
            // 
            this.labelPrefixTitle.AutoSize = true;
            this.labelPrefixTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelPrefixTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrefixTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPrefixTitle.Location = new System.Drawing.Point(37, 34);
            this.labelPrefixTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPrefixTitle.Name = "labelPrefixTitle";
            this.labelPrefixTitle.Size = new System.Drawing.Size(1473, 84);
            this.labelPrefixTitle.TabIndex = 0;
            this.labelPrefixTitle.Text = "PREFIX CONVERSIONS (for Powers of 10)";
            // 
            // labelPrefixInput
            // 
            this.labelPrefixInput.AutoSize = true;
            this.labelPrefixInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrefixInput.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPrefixInput.Location = new System.Drawing.Point(30, 119);
            this.labelPrefixInput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPrefixInput.Name = "labelPrefixInput";
            this.labelPrefixInput.Size = new System.Drawing.Size(531, 55);
            this.labelPrefixInput.TabIndex = 1;
            this.labelPrefixInput.Text = "Please enter your input:";
            // 
            // labelSelect
            // 
            this.labelSelect.AutoSize = true;
            this.labelSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelect.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelSelect.Location = new System.Drawing.Point(30, 198);
            this.labelSelect.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSelect.Name = "labelSelect";
            this.labelSelect.Size = new System.Drawing.Size(1291, 55);
            this.labelSelect.TabIndex = 2;
            this.labelSelect.Text = "Please press the button of the function you wish to execute:";
            // 
            // labelPrefixOutput
            // 
            this.labelPrefixOutput.AutoSize = true;
            this.labelPrefixOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrefixOutput.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelPrefixOutput.Location = new System.Drawing.Point(30, 471);
            this.labelPrefixOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPrefixOutput.Name = "labelPrefixOutput";
            this.labelPrefixOutput.Size = new System.Drawing.Size(333, 55);
            this.labelPrefixOutput.TabIndex = 4;
            this.labelPrefixOutput.Text = "Your output is:";
            // 
            // txtPrefixInput
            // 
            this.txtPrefixInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrefixInput.Location = new System.Drawing.Point(395, 119);
            this.txtPrefixInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPrefixInput.Name = "txtPrefixInput";
            this.txtPrefixInput.Size = new System.Drawing.Size(167, 62);
            this.txtPrefixInput.TabIndex = 5;
            // 
            // txtPrefixOutput
            // 
            this.txtPrefixOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrefixOutput.Location = new System.Drawing.Point(395, 469);
            this.txtPrefixOutput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPrefixOutput.Name = "txtPrefixOutput";
            this.txtPrefixOutput.Size = new System.Drawing.Size(167, 62);
            this.txtPrefixOutput.TabIndex = 6;
            this.txtPrefixOutput.TextChanged += new System.EventHandler(this.txtPrefixOutput_TextChanged);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(856, 448);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(188, 92);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit Application";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(856, 355);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(188, 90);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(37, 246);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 96);
            this.button1.TabIndex = 10;
            this.button1.Text = "Kilo- (1000) to Uni- (1)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUniToKilo
            // 
            this.btnUniToKilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUniToKilo.Location = new System.Drawing.Point(249, 246);
            this.btnUniToKilo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUniToKilo.Name = "btnUniToKilo";
            this.btnUniToKilo.Size = new System.Drawing.Size(200, 96);
            this.btnUniToKilo.TabIndex = 12;
            this.btnUniToKilo.Text = "Uni- (1) to Kilo- (1000)";
            this.btnUniToKilo.UseVisualStyleBackColor = true;
            this.btnUniToKilo.Click += new System.EventHandler(this.btnUniToKilo_Click);
            // 
            // btnMiliToUni
            // 
            this.btnMiliToUni.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMiliToUni.Location = new System.Drawing.Point(461, 246);
            this.btnMiliToUni.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMiliToUni.Name = "btnMiliToUni";
            this.btnMiliToUni.Size = new System.Drawing.Size(200, 96);
            this.btnMiliToUni.TabIndex = 13;
            this.btnMiliToUni.Text = "Mili- (.001) to Uni- (1)";
            this.btnMiliToUni.UseVisualStyleBackColor = true;
            this.btnMiliToUni.Click += new System.EventHandler(this.btnMiliToUni_Click);
            // 
            // btnUniToMili
            // 
            this.btnUniToMili.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUniToMili.Location = new System.Drawing.Point(673, 246);
            this.btnUniToMili.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUniToMili.Name = "btnUniToMili";
            this.btnUniToMili.Size = new System.Drawing.Size(200, 96);
            this.btnUniToMili.TabIndex = 14;
            this.btnUniToMili.Text = "Uni- (1) to Mili- (0.001)";
            this.btnUniToMili.UseVisualStyleBackColor = true;
            this.btnUniToMili.Click += new System.EventHandler(this.btnUniToMili_Click);
            // 
            // PrefixConversions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(1578, 844);
            this.Controls.Add(this.btnUniToMili);
            this.Controls.Add(this.btnMiliToUni);
            this.Controls.Add(this.btnUniToKilo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtPrefixOutput);
            this.Controls.Add(this.txtPrefixInput);
            this.Controls.Add(this.labelPrefixOutput);
            this.Controls.Add(this.labelSelect);
            this.Controls.Add(this.labelPrefixInput);
            this.Controls.Add(this.labelPrefixTitle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PrefixConversions";
            this.Text = "Prefix Conversions";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPrefixTitle;
        private System.Windows.Forms.Label labelPrefixInput;
        private System.Windows.Forms.Label labelSelect;
        private System.Windows.Forms.Label labelPrefixOutput;
        private System.Windows.Forms.TextBox txtPrefixInput;
        private System.Windows.Forms.TextBox txtPrefixOutput;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnUniToKilo;
        private System.Windows.Forms.Button btnMiliToUni;
        private System.Windows.Forms.Button btnUniToMili;
    }
}